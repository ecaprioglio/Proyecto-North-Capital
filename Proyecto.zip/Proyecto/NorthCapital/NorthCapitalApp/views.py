from functools import wraps
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponseForbidden
from django.shortcuts import render, redirect
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_POST


def home(request):
    return render(request, 'index.html')


@never_cache
def login_view(request, perfil='usuario'):
    """perfil='usuario' -> /login/ ; perfil='administrador' -> /login/administrador/"""
    if request.user.is_authenticated:
        return redirect('panel_admin' if request.user.is_staff else 'dashboard')
    error = ''
    if request.method == 'POST':
        user = authenticate(request,
                            username=request.POST.get('username', ''),
                            password=request.POST.get('password', ''))
        # El perfil elegido debe coincidir con el tipo de cuenta (is_staff).
        if user is not None and user.is_staff == (perfil == 'administrador'):
            login(request, user)
            return redirect('panel_admin' if user.is_staff else 'dashboard')
        error = 'No se pudo iniciar sesión. Revisa tus credenciales y el perfil seleccionado.'
    return render(request, 'login.html', {'perfil': perfil, 'error': error})


@require_POST
def logout_view(request):
    logout(request)
    return redirect('login')


@never_cache
def registro(request):
    form = UserCreationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save(commit=False)
        user.password = form.cleaned_data['password1']
        user.is_staff = False
        user.is_superuser = False
        user.save()
        login(request, user)
        return redirect('dashboard')
    return render(request, 'registro.html', {'form': form})


def staff_required(view):
    @wraps(view)
    @login_required
    def wrapped(request, *args, **kwargs):
        if not request.user.is_staff:
            return HttpResponseForbidden('Tu perfil no tiene acceso a este panel.')
        return view(request, *args, **kwargs)
    return wrapped


# Páginas del prototipo original (sin cambios de contenido), ahora protegidas.
@never_cache
@login_required
def dashboard(request):
    # El administrador también puede ver el panel de usuario ("Vista usuario").
    return render(request, 'dashboard.html')


@never_cache
@staff_required
def panel_admin(request):
    return render(request, 'admin.html')


@never_cache
@staff_required
def usuarios(request):
    return render(request, 'admin-usuarios.html')


@login_required
def pagina(request, template):
    return render(request, template)
